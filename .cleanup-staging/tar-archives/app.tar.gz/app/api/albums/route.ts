// API endpoints cho Albums CRUD operations
import { NextRequest, NextResponse } from 'next/server'
import { AlbumService } from '@/lib/database'
import { ApiResponse, AlbumFilter, CreateAlbumForm } from '@/types/database'
import { synologyService } from '@/lib/synology'
import { createFolderName } from '@/lib/utils'

// GET /api/albums - Lấy danh sách albums với filtering
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    
    // Parse filter parameters
    const filter: AlbumFilter = {}
    
    if (searchParams.get('search')) {
      filter.search = searchParams.get('search')!
    }
    
    if (searchParams.get('category')) {
      filter.category = searchParams.get('category') as any
    }
    
    if (searchParams.get('tags')) {
      filter.tags = searchParams.get('tags')!.split(',').map(tag => tag.trim())
    }
    
    if (searchParams.get('created_by')) {
      filter.created_by = searchParams.get('created_by')!
    }
    
    if (searchParams.get('start_date') && searchParams.get('end_date')) {
      filter.date_range = {
        start: new Date(searchParams.get('start_date')!),
        end: new Date(searchParams.get('end_date')!)
      }
    }
    
    const albums = await AlbumService.getAll(filter)
    
    const response: ApiResponse<typeof albums> = {
      success: true,
      data: albums,
      message: `Tìm thấy ${albums.length} album(s)`
    }
    
    return NextResponse.json(response)
    
  } catch (error) {
    console.error('Get albums API error:', error)
    
    const response: ApiResponse<null> = {
      success: false,
      error: 'Lỗi server khi lấy danh sách albums'
    }
    
    return NextResponse.json(response, { status: 500 })
  }
}

// POST /api/albums - Tạo album mới
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate required fields
    if (!body.name || typeof body.name !== 'string' || body.name.trim().length === 0) {
      const response: ApiResponse<null> = {
        success: false,
        error: 'Tên album là bắt buộc'
      }
      return NextResponse.json(response, { status: 400 })
    }
    
    // Validate category if provided
    const validCategories = ['fabric', 'accessory', 'event', 'collection', 'project', 'season', 'client', 'other']
    if (body.category && !validCategories.includes(body.category)) {
      const response: ApiResponse<null> = {
        success: false,
        error: `Category không hợp lệ. Chỉ chấp nhận: ${validCategories.join(', ')}`
      }
      return NextResponse.json(response, { status: 400 })
    }
    
    // Validate tags if provided
    if (body.tags && (!Array.isArray(body.tags) || body.tags.some((tag: any) => typeof tag !== 'string'))) {
      const response: ApiResponse<null> = {
        success: false,
        error: 'Tags phải là mảng các chuỗi'
      }
      return NextResponse.json(response, { status: 400 })
    }
    
    const albumData: CreateAlbumForm = {
      name: body.name.trim(),
      description: body.description?.trim() || undefined,
      category: body.category || 'other',
      subcategory: body.subcategory, // Support subcategories like 'moq', 'new', 'clearance'
      category_path: body.category_path, // Optional: will be auto-generated if not provided
      tags: body.tags || []
    }

    const newAlbum = await AlbumService.create(albumData)

    // Tự động tạo folder trên Synology cho album mới
    // Tổ chức theo hierarchy: /thuvienanh/{category_path}/{album-name}_{id}
    // Example: /thuvienanh/fabrics/moq/album-name_uuid
    const ENABLE_SYNOLOGY_FOLDER_CREATION = process.env.ENABLE_SYNOLOGY_FOLDER_CREATION === 'true'

    if (ENABLE_SYNOLOGY_FOLDER_CREATION) {
      const categoryPath = newAlbum.category_path || newAlbum.category || 'other'
      const folderName = createFolderName(newAlbum.name, newAlbum.id)
      const folderPath = `/Marketing/Ninh/thuvienanh/${categoryPath}/${folderName}`
      console.log(`📁 Creating Synology folder for new album: ${folderPath}`)
      console.log(`   Category Path: "${categoryPath}", Album: "${newAlbum.name}" => Folder: "${folderName}"`)

      try {
        // Ensure authentication before creating folder
        const authSuccess = await synologyService.fileStation.authenticate()
        if (!authSuccess) {
          console.error('❌ Synology authentication failed when creating folder')
        } else {
          const folderCreated = await synologyService.fileStation.createFolder(folderPath)
          if (folderCreated) {
            console.log(`✅ Synology folder created: ${folderPath}`)
          } else {
            console.warn(`⚠️ Failed to create Synology folder for album: ${newAlbum.id}`)
            console.warn(`   Attempted path: ${folderPath}`)
          }
        }
      } catch (error) {
        console.error('❌ Error creating Synology folder:', error)
        console.error(`   Album: ${newAlbum.name} (${newAlbum.id})`)
        console.error(`   Path: ${folderPath}`)
        // Không fail request nếu tạo folder thất bại
      }
    } else {
      const categoryPath = newAlbum.category_path || newAlbum.category || 'other'
      console.log(`ℹ️ Synology folder creation disabled. Album created in database only.`)
      console.log(`   Manual folder creation required: /Marketing/Ninh/thuvienanh/${categoryPath}/${createFolderName(newAlbum.name, newAlbum.id)}`)
    }

    const response: ApiResponse<typeof newAlbum> = {
      success: true,
      data: newAlbum,
      message: 'Tạo album thành công'
    }

    return NextResponse.json(response, { status: 201 })
    
  } catch (error) {
    console.error('Create album API error:', error)
    
    const response: ApiResponse<null> = {
      success: false,
      error: 'Lỗi server khi tạo album'
    }
    
    return NextResponse.json(response, { status: 500 })
  }
}
